package com.bandtec.com.br.EntregavelSprint01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntregavelSprint01Application {

	public static void main(String[] args) {
		SpringApplication.run(EntregavelSprint01Application.class, args);
	}

}
