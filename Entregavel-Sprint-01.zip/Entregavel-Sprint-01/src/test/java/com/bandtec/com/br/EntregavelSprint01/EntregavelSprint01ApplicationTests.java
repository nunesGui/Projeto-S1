package com.bandtec.com.br.EntregavelSprint01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntregavelSprint01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
